import type { Deal, Contact, Activity, Proposal } from '../types';

const mockDeals: Deal[] = [
  {
    id: 1,
    title: 'Tech Solutions SA - João Silva',
    value: 150000,
    stage: 'lead',
    company: 'Tech Solutions SA',
    contact: 'João Silva',
    firstContactDate: '2024-02-01',
    probability: 60,
    lastActivity: 'Reunião de apresentação',
    responsibleName: 'João Silva',
    phone: '(11) 98765-4321',
    email: 'joao.silva@techsolutions.com',
    industry: 'Tecnologia',
    contactResponsible: 'Maria Santos',
    companyResponsible: 'Carlos Oliveira',
    contextInfo: 'Empresa interessada em soluções de IA',
    interactionHistory: 'Primeira reunião realizada com sucesso',
    utmCampaign: 'google_ads_q1',
    utmAdSet: 'ia_solutions',
    utmAd: 'ia_empresarial',
    utmKeyword: 'solucoes ia empresas'
  },
  {
    id: 2,
    title: 'Inovação Ltd - Maria Santos',
    value: 75000,
    stage: 'contact',
    company: 'Inovação Ltd',
    contact: 'Maria Santos',
    firstContactDate: '2024-02-15',
    probability: 40,
    lastActivity: 'Envio de proposta',
    responsibleName: 'Maria Santos',
    phone: '(11) 98765-4322',
    email: 'maria.santos@inovacao.com',
    industry: 'Consultoria',
    contactResponsible: 'Pedro Costa',
    companyResponsible: 'Ana Silva',
    contextInfo: 'Interesse em consultoria de processos',
    interactionHistory: 'Cliente demonstrou interesse inicial',
    utmCampaign: 'linkedin_ads',
    utmAdSet: 'consultoria_processos',
    utmAd: 'otimizacao_processos',
    utmKeyword: 'consultoria processos empresariais'
  },
  {
    id: 3,
    title: 'Mega Corp - Pedro Costa',
    value: 200000,
    stage: 'proposal',
    company: 'Mega Corp',
    contact: 'Pedro Costa',
    firstContactDate: '2024-01-20',
    probability: 80,
    lastActivity: 'Negociação de valores',
    responsibleName: 'Pedro Costa',
    phone: '(11) 98765-4323',
    email: 'pedro.costa@megacorp.com',
    industry: 'Manufatura',
    contactResponsible: 'Carlos Santos',
    companyResponsible: 'Lucia Lima',
    contextInfo: 'Projeto de automação industrial',
    interactionHistory: 'Várias reuniões técnicas realizadas',
    utmCampaign: 'facebook_ads',
    utmAdSet: 'automacao_industrial',
    utmAd: 'industria_40',
    utmKeyword: 'automacao industria 4.0'
  }
];

const mockContacts: Contact[] = [
  {
    id: 1,
    name: 'João Silva',
    email: 'joao.silva@techsolutions.com',
    phone: '(11) 98765-4321',
    company: 'Tech Solutions SA',
    position: 'CTO',
    lastContact: '2024-03-10',
    status: 'active'
  },
  {
    id: 2,
    name: 'Maria Santos',
    email: 'maria.santos@inovacao.com',
    phone: '(11) 98765-4322',
    company: 'Inovação Ltd',
    position: 'Diretora de Projetos',
    lastContact: '2024-03-12',
    status: 'active'
  }
];

const mockActivities: Activity[] = [
  {
    id: 1,
    type: 'meeting',
    title: 'Apresentação Inicial',
    description: 'Apresentação da solução para o cliente',
    date: '2024-03-20T10:00:00',
    status: 'pending',
    relatedTo: {
      type: 'deal',
      id: 1,
      name: 'Sistema ERP Customizado'
    }
  },
  {
    id: 2,
    type: 'call',
    title: 'Follow-up Proposta',
    description: 'Ligar para verificar feedback da proposta',
    date: '2024-03-18T14:30:00',
    status: 'completed',
    relatedTo: {
      type: 'contact',
      id: 2,
      name: 'Maria Santos'
    }
  }
];

const mockProposals: Proposal[] = [
  {
    id: 1,
    title: 'Proposta ERP Customizado v1',
    dealId: 1,
    dealTitle: 'Sistema ERP Customizado',
    company: 'Tech Solutions SA',
    value: 150000,
    status: 'enviado',
    createdAt: '2024-03-01',
    validUntil: '2024-04-01',
    documents: []
  },
  {
    id: 2,
    title: 'Consultoria IA - Proposta Inicial',
    dealId: 2,
    dealTitle: 'Consultoria em IA',
    company: 'Inovação Ltd',
    value: 75000,
    status: 'a_enviar',
    createdAt: '2024-03-10',
    validUntil: '2024-04-10',
    documents: []
  }
];

export { mockDeals, mockContacts, mockActivities, mockProposals };