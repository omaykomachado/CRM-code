import React, { useState } from 'react';
import { BarChart2, PieChart, LineChart, TrendingUp, DollarSign, Users, Target } from 'lucide-react';
import { useDeals } from '../hooks/useSupabase';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  ChartOptions
} from 'chart.js';
import { Line, Bar, Pie } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

export function Reports() {
  const { deals } = useDeals();
  const [dateRange, setDateRange] = useState({
    startDate: '',
    endDate: ''
  });

  // Filter deals based on date range
  const filteredDeals = deals.filter(deal => {
    if (!dateRange.startDate && !dateRange.endDate) return true;
    const dealDate = new Date(deal.firstContactDate || '');
    const start = dateRange.startDate ? new Date(dateRange.startDate) : null;
    const end = dateRange.endDate ? new Date(dateRange.endDate) : null;
    
    return (!start || dealDate >= start) && (!end || dealDate <= end);
  });

  // Calculate metrics
  const totalDeals = filteredDeals.length;
  const closedDeals = filteredDeals.filter(deal => deal.stage === 'closed').length;
  const treasureDeals = filteredDeals.filter(deal => deal.stage === 'treasure').length;
  const conversionRate = totalDeals > 0 ? (closedDeals / totalDeals) * 100 : 0;

  const stageDistribution = [
    { stage: 'Baú de Leads', count: filteredDeals.filter(d => d.stage === 'treasure').length },
    { stage: 'Leads', count: filteredDeals.filter(d => d.stage === 'lead').length },
    { stage: 'Primeiro Contato', count: filteredDeals.filter(d => d.stage === 'contact').length },
    { stage: 'Proposta', count: filteredDeals.filter(d => d.stage === 'proposal').length },
    { stage: 'Negociação', count: filteredDeals.filter(d => d.stage === 'negotiation').length },
    { stage: 'Fechado', count: filteredDeals.filter(d => d.stage === 'closed').length },
  ];

  const totalValue = filteredDeals.reduce((sum, deal) => sum + deal.value, 0);
  const averageValue = totalDeals > 0 ? totalValue / totalDeals : 0;

  // Prepare data for charts
  const monthlyData = Array.from({ length: 12 }, (_, i) => {
    const month = new Date(2024, i);
    const dealsInMonth = filteredDeals.filter(d => new Date(d.expectedCloseDate).getMonth() === i);
    return {
      month: month.toLocaleString('pt-BR', { month: 'short' }),
      value: dealsInMonth.reduce((sum, d) => sum + d.value, 0),
      count: dealsInMonth.length
    };
  });

  const lineChartData = {
    labels: monthlyData.map(d => d.month),
    datasets: [
      {
        label: 'Valor Total (R$)',
        data: monthlyData.map(d => d.value),
        borderColor: '#BFFF04',
        backgroundColor: '#BFFF04',
        tension: 0.4
      }
    ]
  };

  const barChartData = {
    labels: monthlyData.map(d => d.month),
    datasets: [
      {
        label: 'Quantidade de Negócios',
        data: monthlyData.map(d => d.count),
        backgroundColor: '#BFFF04'
      }
    ]
  };

  const pieChartData = {
    labels: stageDistribution.map(d => d.stage),
    datasets: [
      {
        data: stageDistribution.map(d => d.count),
        backgroundColor: [
          '#FF6B6B',
          '#4ECDC4',
          '#45B7D1',
          '#96CEB4',
          '#FFEEAD',
          '#BFFF04'
        ]
      }
    ]
  };

  const chartOptions: ChartOptions<'line' | 'bar'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom',
        labels: {
          color: '#FFFFFF'
        }
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          color: '#2A2A2A'
        },
        ticks: {
          color: '#FFFFFF'
        }
      },
      x: {
        grid: {
          color: '#2A2A2A'
        },
        ticks: {
          color: '#FFFFFF'
        }
      }
    }
  };

  const pieChartOptions: ChartOptions<'pie'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom',
        labels: {
          color: '#FFFFFF'
        }
      }
    }
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-[#BFFF04]">Relatórios</h1>
        <div className="flex gap-4">
          <input
            type="date"
            className="bg-[#2A2A2A] text-white px-4 py-2 rounded-lg"
            value={dateRange.startDate}
            onChange={(e) => setDateRange(prev => ({...prev, startDate: e.target.value}))}
          />
          <input
            type="date"
            className="bg-[#2A2A2A] text-white px-4 py-2 rounded-lg"
            value={dateRange.endDate}
            onChange={(e) => setDateRange(prev => ({...prev, endDate: e.target.value}))}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <div className="bg-[#2A2A2A] rounded-lg p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="bg-[#BFFF04]/10 p-2 rounded-lg">
              <DollarSign className="h-6 w-6 text-[#BFFF04]" />
            </div>
            <div>
              <p className="text-sm text-gray-400">Valor Total</p>
              <p className="text-xl font-bold text-white">
                {new Intl.NumberFormat('pt-BR', {
                  style: 'currency',
                  currency: 'BRL'
                }).format(totalValue)}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-[#2A2A2A] rounded-lg p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="bg-[#BFFF04]/10 p-2 rounded-lg">
              <Users className="h-6 w-6 text-[#BFFF04]" />
            </div>
            <div>
              <p className="text-sm text-gray-400">Total de Negócios</p>
              <p className="text-xl font-bold text-white">{totalDeals}</p>
            </div>
          </div>
        </div>

        <div className="bg-[#2A2A2A] rounded-lg p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="bg-[#BFFF04]/10 p-2 rounded-lg">
              <Target className="h-6 w-6 text-[#BFFF04]" />
            </div>
            <div>
              <p className="text-sm text-gray-400">Taxa de Conversão</p>
              <p className="text-xl font-bold text-white">{conversionRate.toFixed(1)}%</p>
            </div>
          </div>
        </div>

        <div className="bg-[#2A2A2A] rounded-lg p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="bg-[#BFFF04]/10 p-2 rounded-lg">
              <DollarSign className="h-6 w-6 text-[#BFFF04]" />
            </div>
            <div>
              <p className="text-sm text-gray-400">Ticket Médio</p>
              <p className="text-xl font-bold text-white">
                {new Intl.NumberFormat('pt-BR', {
                  style: 'currency',
                  currency: 'BRL'
                }).format(averageValue)}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <div className="bg-[#2A2A2A] rounded-lg p-6">
          <h2 className="text-xl font-bold text-[#BFFF04] mb-4">Evolução Mensal (Valor)</h2>
          <div style={{ height: '300px' }}>
            <Line data={lineChartData} options={chartOptions} />
          </div>
        </div>

        <div className="bg-[#2A2A2A] rounded-lg p-6">
          <h2 className="text-xl font-bold text-[#BFFF04] mb-4">Evolução Mensal (Quantidade)</h2>
          <div style={{ height: '300px' }}>
            <Bar data={barChartData} options={chartOptions} />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[#2A2A2A] rounded-lg p-6">
          <h2 className="text-xl font-bold text-[#BFFF04] mb-4">Distribuição por Estágio</h2>
          <div style={{ height: '300px' }}>
            <Pie data={pieChartData} options={pieChartOptions} />
          </div>
        </div>

        <div className="bg-[#2A2A2A] rounded-lg p-6">
          <h2 className="text-xl font-bold text-[#BFFF04] mb-4">Métricas por Estágio</h2>
          <div className="space-y-4">
            {stageDistribution.map((stage, index) => (
              <div key={index} className="flex items-center justify-between">
                <span className="text-white">{stage.stage}</span>
                <div className="flex items-center gap-2">
                  <span className="text-[#BFFF04]">{stage.count}</span>
                  <span className="text-gray-400">
                    ({((stage.count / totalDeals) * 100).toFixed(1)}%)
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}