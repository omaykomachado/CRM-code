import React, { useState } from 'react';
import { FileText, Download, Send, Clock, CheckCircle, XCircle, Plus, X, Link, Edit2, Trash2, ChevronDown } from 'lucide-react';
import { mockProposals } from '../data/mockData';
import type { Proposal, ExportOptions } from '../types';
import toast from 'react-hot-toast';
import { exportToCSV, exportToTSV, exportToPDF, exportToExcel, openInGoogleSheets } from '../hooks/useSupabase';

export function Proposals() {
  const [proposals, setProposals] = useState<Proposal[]>(mockProposals);
  const [showNewProposalModal, setShowNewProposalModal] = useState(false);
  const [editingProposal, setEditingProposal] = useState<Proposal | null>(null);
  const [showExportMenu, setShowExportMenu] = useState(false);
  const [newProposal, setNewProposal] = useState<Partial<Proposal>>({
    title: '',
    dealId: 0,
    dealTitle: '',
    company: '',
    value: 0,
    status: 'a_enviar',
    createdAt: new Date().toISOString(),
    validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    driveLink: '',
    documents: []
  });

  const getStatusIcon = (status: Proposal['status']) => {
    switch (status) {
      case 'a_enviar':
        return Clock;
      case 'enviado':
        return Send;
      case 'aguardando_aprovacao':
        return Clock;
      case 'aprovado':
        return CheckCircle;
      case 'recusado':
        return XCircle;
      default:
        return FileText;
    }
  };

  const getStatusColor = (status: Proposal['status']) => {
    switch (status) {
      case 'a_enviar':
        return 'text-yellow-500 bg-yellow-500/10';
      case 'enviado':
        return 'text-blue-500 bg-blue-500/10';
      case 'aguardando_aprovacao':
        return 'text-orange-500 bg-orange-500/10';
      case 'aprovado':
        return 'text-green-500 bg-green-500/10';
      case 'recusado':
        return 'text-red-500 bg-red-500/10';
      default:
        return 'text-gray-500 bg-gray-500/10';
    }
  };

  const getStatusLabel = (status: Proposal['status']) => {
    switch (status) {
      case 'a_enviar':
        return 'A enviar';
      case 'enviado':
        return 'Enviado';
      case 'aguardando_aprovacao':
        return 'Aguardando Aprovação';
      case 'aprovado':
        return 'Aprovado';
      case 'recusado':
        return 'Recusado';
      default:
        return status;
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const handleCreateProposal = () => {
    if (!newProposal.title || !newProposal.company || !newProposal.value) {
      toast.error('Título, empresa e valor são obrigatórios');
      return;
    }

    const proposal: Proposal = {
      id: proposals.length + 1,
      title: newProposal.title || '',
      dealId: newProposal.dealId || 0,
      dealTitle: newProposal.dealTitle || '',
      company: newProposal.company || '',
      value: newProposal.value || 0,
      status: 'a_enviar',
      createdAt: new Date().toISOString(),
      validUntil: newProposal.validUntil || new Date().toISOString(),
      driveLink: newProposal.driveLink || '',
      documents: []
    };

    setProposals([...proposals, proposal]);
    setShowNewProposalModal(false);
    toast.success('Proposta criada com sucesso!');
  };

  const handleUpdateProposal = (proposal: Proposal) => {
    setProposals(proposals.map(p => p.id === proposal.id ? proposal : p));
    setEditingProposal(null);
    toast.success('Proposta atualizada com sucesso!');
  };

  const handleDeleteProposal = (id: number) => {
    if (confirm('Tem certeza que deseja excluir esta proposta?')) {
      setProposals(proposals.filter(p => p.id !== id));
      toast.success('Proposta excluída com sucesso!');
    }
  };

  const handleDeleteDocument = (proposalId: number, documentId: number) => {
    setProposals(proposals.map(proposal => {
      if (proposal.id === proposalId) {
        return {
          ...proposal,
          documents: proposal.documents.filter(doc => doc.id !== documentId)
        };
      }
      return proposal;
    }));
    toast.success('Documento removido com sucesso!');
  };

  const handleExport = (format: ExportOptions['format']) => {
    const data = proposals.map(proposal => ({
      'Título': proposal.title,
      'Empresa': proposal.company,
      'Valor': formatCurrency(proposal.value),
      'Status': getStatusLabel(proposal.status),
      'Criado em': new Date(proposal.createdAt).toLocaleDateString('pt-BR'),
      'Válido até': new Date(proposal.validUntil).toLocaleDateString('pt-BR'),
      'Link do Drive': proposal.driveLink || '-',
      'Documentos': proposal.documents.map(doc => doc.name).join(', ') || '-'
    }));

    switch (format) {
      case 'csv-excel':
        exportToCSV(data, 'propostas-excel.csv', true);
        break;
      case 'csv':
        exportToCSV(data, 'propostas.csv', false);
        break;
      case 'tsv':
        exportToTSV(data, 'propostas.tsv');
        break;
      case 'pdf':
        exportToPDF(data, 'propostas.pdf');
        break;
      case 'xlsx':
      case 'xls':
        exportToExcel(data, `propostas.${format}`);
        break;
      case 'google-sheets':
        openInGoogleSheets(data);
        break;
    }
    
    setShowExportMenu(false);
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-[#BFFF04]">Propostas</h1>
        <div className="flex gap-2">
          <div className="relative">
            <button
              onClick={() => setShowExportMenu(!showExportMenu)}
              className="bg-[#BFFF04] text-[#1A1A1A] px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-[#BFFF04]/90 transition-colors"
            >
              <Download className="h-5 w-5" />
              Exportar
              <ChevronDown className="h-4 w-4" />
            </button>
            {showExportMenu && (
              <div className="absolute right-0 mt-2 w-48 bg-[#2A2A2A] rounded-lg shadow-lg py-2 z-50">
                <button
                  onClick={() => handleExport('csv-excel')}
                  className="w-full px-4 py-2 text-left text-white hover:bg-[#1A1A1A] transition-colors"
                >
                  CSV (Excel)
                </button>
                <button
                  onClick={() => handleExport('csv')}
                  className="w-full px-4 py-2 text-left text-white hover:bg-[#1A1A1A] transition-colors"
                >
                  CSV
                </button>
                <button
                  onClick={() => handleExport('tsv')}
                  className="w-full px-4 py-2 text-left text-white hover:bg-[#1A1A1A] transition-colors"
                >
                  TSV
                </button>
                <button
                  onClick={() => handleExport('pdf')}
                  className="w-full px-4 py-2 text-left text-white hover:bg-[#1A1A1A] transition-colors"
                >
                  PDF
                </button>
                <button
                  onClick={() => handleExport('xlsx')}
                  className="w-full px-4 py-2 text-left text-white hover:bg-[#1A1A1A] transition-colors"
                >
                  XLSX
                </button>
                <button
                  onClick={() => handleExport('xls')}
                  className="w-full px-4 py-2 text-left text-white hover:bg-[#1A1A1A] transition-colors"
                >
                  XLS
                </button>
                <button
                  onClick={() => handleExport('google-sheets')}
                  className="w-full px-4 py-2 text-left text-white hover:bg-[#1A1A1A] transition-colors"
                >
                  Google Sheets
                </button>
              </div>
            )}
          </div>
          <button
            onClick={() => setShowNewProposalModal(true)}
            className="bg-[#BFFF04] text-[#1A1A1A] px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-[#BFFF04]/90 transition-colors"
          >
            <FileText className="h-5 w-5" />
            Nova Proposta
          </button>
        </div>
      </div>

      <div className="bg-[#2A2A2A] rounded-lg overflow-x-auto">
        <table className="w-full min-w-[800px]">
          <thead>
            <tr className="bg-[#1A1A1A]">
              <th className="px-4 py-3 text-left text-[#BFFF04] font-medium">Título</th>
              <th className="px-4 py-3 text-left text-[#BFFF04] font-medium">Empresa</th>
              <th className="px-4 py-3 text-left text-[#BFFF04] font-medium">Valor</th>
              <th className="px-4 py-3 text-left text-[#BFFF04] font-medium">Status</th>
              <th className="px-4 py-3 text-left text-[#BFFF04] font-medium">Válido até</th>
              <th className="px-4 py-3 text-left text-[#BFFF04] font-medium">Documentos</th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody>
            {proposals.map((proposal) => {
              const StatusIcon = getStatusIcon(proposal.status);
              const statusColor = getStatusColor(proposal.status);

              return (
                <tr key={proposal.id} className="border-t border-[#1A1A1A] hover:bg-[#1A1A1A]/50">
                  <td className="px-4 py-3 text-white">{proposal.title}</td>
                  <td className="px-4 py-3 text-gray-400">{proposal.company}</td>
                  <td className="px-4 py-3 text-[#BFFF04]">{formatCurrency(proposal.value)}</td>
                  <td className="px-4 py-3">
                    <div className={`px-3 py-1 rounded-full inline-flex items-center gap-2 ${statusColor}`}>
                      <StatusIcon className="h-4 w-4" />
                      <span className="text-sm">{getStatusLabel(proposal.status)}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-gray-400">
                    {new Date(proposal.validUntil).toLocaleDateString('pt-BR')}
                  </td>
                  <td className="px-4 py-3">
                    {proposal.documents.length > 0 ? (
                      <div className="space-y-1">
                        {proposal.documents.map(doc => (
                          <div key={doc.id} className="flex items-center gap-2">
                            <a
                              href={doc.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-[#BFFF04] hover:text-[#BFFF04]/80 transition-colors text-sm"
                            >
                              {doc.name}
                            </a>
                            <button
                              onClick={() => handleDeleteDocument(proposal.id, doc.id)}
                              className="text-red-500 hover:text-red-400 transition-colors"
                            >
                              <X className="h-4 w-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <span className="text-gray-400 text-sm">Nenhum documento</span>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setEditingProposal(proposal)}
                        className="text-gray-400 hover:text-[#BFFF04] transition-colors"
                      >
                        <Edit2 className="h-5 w-5" />
                      </button>
                      <button
                        onClick={() => handleDeleteProposal(proposal.id)}
                        className="text-gray-400 hover:text-red-500 transition-colors"
                      >
                        <Trash2 className="h-5 w-5" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {(showNewProposalModal || editingProposal) && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-[#2A2A2A] rounded-lg p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-[#BFFF04]">
                {editingProposal ? 'Editar Proposta' : 'Nova Proposta'}
              </h2>
              <button
                onClick={() => {
                  setEditingProposal(null);
                  setShowNewProposalModal(false);
                }}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm text-gray-400 mb-1">Título *</label>
                <input
                  type="text"
                  className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                  value={editingProposal?.title || newProposal.title}
                  onChange={(e) => {
                    if (editingProposal) {
                      setEditingProposal({ ...editingProposal, title: e.target.value });
                    } else {
                      setNewProposal({ ...newProposal, title: e.target.value });
                    }
                  }}
                />
              </div>

              <div>
                <label className="block text-sm text-gray-400 mb-1">Empresa *</label>
                <input
                  type="text"
                  className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                  value={editingProposal?.company || newProposal.company}
                  onChange={(e) => {
                    if (editingProposal) {
                      setEditingProposal({ ...editingProposal, company: e.target.value });
                    } else {
                      setNewProposal({ ...newProposal, company: e.target.value });
                    }
                  }}
                />
              </div>

              <div>
                <label className="block text-sm text-gray-400 mb-1">Valor *</label>
                <input
                  type="number"
                  className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                  value={editingProposal?.value || newProposal.value}
                  onChange={(e) => {
                    if (editingProposal) {
                      setEditingProposal({ ...editingProposal, value: Number(e.target.value) });
                    } else {
                      setNewProposal({ ...newProposal, value: Number(e.target.value) });
                    }
                  }}
                />
              </div>

              <div>
                <label className="block text-sm text-gray-400 mb-1">Status</label>
                <select
                  className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                  value={editingProposal?.status || newProposal.status}
                  onChange={(e) => {
                    const status = e.target.value as Proposal['status'];
                    if (editingProposal) {
                      setEditingProposal({ ...editingProposal, status });
                    } else {
                      setNewProposal({ ...newProposal, status });
                    }
                  }}
                >
                  <option value="a_enviar">A enviar</option>
                  <option value="enviado">Enviado</option>
                  <option value="aguardando_aprovacao">Aguardando Aprovação</option>
                  <option value="aprovado">Aprovado</option>
                  <option value="recusado">Recusado</option>
                </select>
              </div>

              <div>
                <label className="block text-sm text-gray-400 mb-1">Link do Drive</label>
                <input
                  type="url"
                  className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                  value={editingProposal?.driveLink || newProposal.driveLink}
                  onChange={(e) => {
                    if (editingProposal) {
                      setEditingProposal({ ...editingProposal, driveLink: e.target.value });
                    } else {
                      setNewProposal({ ...newProposal, driveLink: e.target.value });
                    }
                  }}
                  placeholder="https://drive.google.com/..."
                />
              </div>

              <div>
                <label className="block text-sm text-gray-400 mb-1">Documentos</label>
                <input
                  type="file"
                  multiple
                  className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                  onChange={(e) => {
                    const files = Array.from(e.target.files || []);
                    const newDocs = files.map((file, index) => ({
                      id: Date.now() + index,
                      name: file.name,
                      url: URL.createObjectURL(file)
                    }));

                    if (editingProposal) {
                      setEditingProposal({
                        ...editingProposal,
                        documents: [...editingProposal.documents, ...newDocs]
                      });
                    } else {
                      setNewProposal({
                        ...newProposal,
                        documents: [...(newProposal.documents || []), ...newDocs]
                      });
                    }
                  }}
                />
              </div>

              <div>
                <label className="block text-sm text-gray-400 mb-1">Válido até</label>
                <input
                  type="date"
                  className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                  value={editingProposal?.validUntil?.split('T')[0] || newProposal.validUntil?.split('T')[0]}
                  onChange={(e) => {
                    if (editingProposal) {
                      setEditingProposal({ ...editingProposal, validUntil: e.target.value });
                    } else {
                      setNewProposal({ ...newProposal, validUntil: e.target.value });
                    }
                  }}
                />
              </div>
            </div>

            <div className="mt-6 flex justify-end gap-4">
              <button
                onClick={() => {
                  setEditingProposal(null);
                  setShowNewProposalModal(false);
                }}
                className="px-4 py-2 text-gray-400 hover:text-white transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={() => {
                  if (editingProposal) {
                    handleUpdateProposal(editingProposal);
                  } else {
                    handleCreateProposal();
                  }
                }}
                className="bg-[#BFFF04] text-[#1A1A1A] px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-[#BFFF04]/90 transition-colors"
              >
                <Plus className="h-5 w-5" />
                {editingProposal ? 'Salvar Alterações' : 'Criar Proposta'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}