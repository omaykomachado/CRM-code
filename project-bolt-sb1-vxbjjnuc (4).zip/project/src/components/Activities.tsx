import React, { useState } from 'react';
import { Calendar as CalendarIcon, Phone, Video, Mail, Check, Clock, Plus, Filter, X, Edit2 } from 'lucide-react';
import { mockActivities } from '../data/mockData';
import type { Activity } from '../types';
import Calendar from 'react-calendar';
import { useDeals } from '../hooks/useSupabase';
import toast from 'react-hot-toast';

export function Activities() {
  const [activities, setActivities] = useState<Activity[]>(mockActivities);
  const [showNewActivityModal, setShowNewActivityModal] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [editingActivity, setEditingActivity] = useState<Activity | null>(null);
  const { deals } = useDeals();
  const [newActivity, setNewActivity] = useState<Partial<Activity>>({
    type: 'task',
    title: '',
    description: '',
    date: new Date().toISOString(),
    status: 'pending',
    relatedTo: {
      type: 'personal',
      id: 0,
      name: 'Tarefa Pessoal'
    }
  });

  const getActivityIcon = (type: Activity['type']) => {
    switch (type) {
      case 'call':
        return Phone;
      case 'meeting':
        return CalendarIcon;
      case 'email':
        return Mail;
      case 'task':
        return Check;
      default:
        return CalendarIcon;
    }
  };

  const formatDateToLocal = (date: string) => {
    return new Date(date).toLocaleString('sv-SE', { timeZone: 'America/Sao_Paulo' }).slice(0, 16);
  };

  const parseLocalDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toISOString();
  };

  const handleCreateActivity = () => {
    if (!newActivity.title) {
      toast.error('O título é obrigatório');
      return;
    }

    const activity: Activity = {
      id: activities.length + 1,
      type: newActivity.type || 'task',
      title: newActivity.title,
      description: newActivity.description || '',
      date: parseLocalDate(newActivity.date || new Date().toISOString()),
      status: 'pending',
      relatedTo: newActivity.relatedTo || {
        type: 'personal',
        id: 0,
        name: 'Tarefa Pessoal'
      }
    };

    setActivities([...activities, activity]);
    setShowNewActivityModal(false);
    toast.success('Atividade criada com sucesso!');
    resetNewActivityForm();
  };

  const handleUpdateActivity = (activity: Activity) => {
    setActivities(activities.map(a => a.id === activity.id ? activity : a));
    setEditingActivity(null);
    toast.success('Atividade atualizada com sucesso!');
  };

  const handleDeleteActivity = (id: number) => {
    if (confirm('Tem certeza que deseja excluir esta atividade?')) {
      setActivities(activities.filter(a => a.id !== id));
      toast.success('Atividade excluída com sucesso!');
    }
  };

  const resetNewActivityForm = () => {
    setNewActivity({
      type: 'task',
      title: '',
      description: '',
      date: new Date().toISOString(),
      status: 'pending',
      relatedTo: {
        type: 'personal',
        id: 0,
        name: 'Tarefa Pessoal'
      }
    });
  };

  const handleCompleteActivity = (id: number) => {
    setActivities(
      activities.map(activity =>
        activity.id === id ? { ...activity, status: 'completed' } : activity
      )
    );
    toast.success('Atividade marcada como concluída!');
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-[#BFFF04]">Atividades</h1>
        <button
          onClick={() => setShowNewActivityModal(true)}
          className="bg-[#BFFF04] text-[#1A1A1A] px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-[#BFFF04]/90 transition-colors"
        >
          <CalendarIcon className="h-5 w-5" />
          Nova Atividade
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[#2A2A2A] rounded-lg p-6">
          <h2 className="text-xl font-bold text-[#BFFF04] mb-4">Próximas Atividades</h2>
          <div className="space-y-4">
            {activities
              .filter(activity => activity.status === 'pending')
              .map(activity => {
                const Icon = getActivityIcon(activity.type);
                return (
                  <div
                    key={activity.id}
                    className="bg-[#1A1A1A] rounded-lg p-4 flex items-start gap-4"
                  >
                    <div className="bg-[#BFFF04]/10 p-2 rounded-lg">
                      <Icon className="h-6 w-6 text-[#BFFF04]" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-white font-medium">{activity.title}</h3>
                      <p className="text-gray-400 text-sm">{activity.description}</p>
                      <div className="flex items-center gap-4 mt-2">
                        <span className="text-sm text-[#BFFF04]">
                          {new Date(activity.date).toLocaleString('pt-BR')}
                        </span>
                        <span className="text-sm text-gray-400">
                          {activity.relatedTo.type === 'deal' ? 'Negócio: ' : 'Tarefa Pessoal'}
                          {activity.relatedTo.type === 'deal' && activity.relatedTo.name}
                        </span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => setEditingActivity(activity)}
                        className="text-gray-400 hover:text-[#BFFF04] transition-colors"
                      >
                        <Edit2 className="h-5 w-5" />
                      </button>
                      <button
                        onClick={() => handleDeleteActivity(activity.id)}
                        className="text-gray-400 hover:text-red-500 transition-colors"
                      >
                        <X className="h-5 w-5" />
                      </button>
                      <button
                        onClick={() => handleCompleteActivity(activity.id)}
                        className="text-gray-400 hover:text-[#BFFF04] transition-colors"
                      >
                        <Check className="h-5 w-5" />
                      </button>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>

        <div className="bg-[#2A2A2A] rounded-lg p-6">
          <h2 className="text-xl font-bold text-[#BFFF04] mb-4">Calendário</h2>
          <Calendar
            onChange={setSelectedDate}
            value={selectedDate}
            className="w-full"
            tileClassName={({ date }) => {
              const hasActivity = activities.some(
                activity =>
                  new Date(activity.date).toDateString() === date.toDateString()
              );
              return hasActivity ? 'react-calendar__tile--hasActivity' : '';
            }}
          />
        </div>
      </div>

      {(showNewActivityModal || editingActivity) && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-[#2A2A2A] rounded-lg p-6 max-w-2xl w-full">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-[#BFFF04]">
                {editingActivity ? 'Editar Atividade' : 'Nova Atividade'}
              </h2>
              <button
                onClick={() => {
                  setShowNewActivityModal(false);
                  setEditingActivity(null);
                  resetNewActivityForm();
                }}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm text-gray-400 mb-1">Tipo</label>
                <select
                  className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                  value={editingActivity?.type || newActivity.type}
                  onChange={(e) => {
                    if (editingActivity) {
                      setEditingActivity({ ...editingActivity, type: e.target.value as Activity['type'] });
                    } else {
                      setNewActivity({ ...newActivity, type: e.target.value as Activity['type'] });
                    }
                  }}
                >
                  <option value="task">Tarefa</option>
                  <option value="call">Ligação</option>
                  <option value="meeting">Reunião</option>
                  <option value="email">E-mail</option>
                </select>
              </div>

              <div>
                <label className="block text-sm text-gray-400 mb-1">Título *</label>
                <input
                  type="text"
                  className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                  value={editingActivity?.title || newActivity.title}
                  onChange={(e) => {
                    if (editingActivity) {
                      setEditingActivity({ ...editingActivity, title: e.target.value });
                    } else {
                      setNewActivity({ ...newActivity, title: e.target.value });
                    }
                  }}
                />
              </div>

              <div>
                <label className="block text-sm text-gray-400 mb-1">Descrição</label>
                <textarea
                  className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white h-24"
                  value={editingActivity?.description || newActivity.description}
                  onChange={(e) => {
                    if (editingActivity) {
                      setEditingActivity({ ...editingActivity, description: e.target.value });
                    } else {
                      setNewActivity({ ...newActivity, description: e.target.value });
                    }
                  }}
                />
              </div>

              <div>
                <label className="block text-sm text-gray-400 mb-1">Data e Hora</label>
                <input
                  type="datetime-local"
                  className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                  value={formatDateToLocal(editingActivity?.date || newActivity.date || '')}
                  onChange={(e) => {
                    const newDate = parseLocalDate(e.target.value);
                    if (editingActivity) {
                      setEditingActivity({ ...editingActivity, date: newDate });
                    } else {
                      setNewActivity({ ...newActivity, date: newDate });
                    }
                  }}
                />
              </div>

              <div>
                <label className="block text-sm text-gray-400 mb-1">Relacionado a</label>
                <select
                  className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                  value={editingActivity?.relatedTo.id || newActivity.relatedTo?.id || 'personal'}
                  onChange={(e) => {
                    const value = e.target.value;
                    const relatedTo = value === 'personal'
                      ? { type: 'personal' as const, id: 0, name: 'Tarefa Pessoal' }
                      : {
                          type: 'deal' as const,
                          id: Number(value),
                          name: deals.find(d => d.id === Number(value))?.title || ''
                        };

                    if (editingActivity) {
                      setEditingActivity({ ...editingActivity, relatedTo });
                    } else {
                      setNewActivity({ ...newActivity, relatedTo });
                    }
                  }}
                >
                  <option value="personal">Tarefa Pessoal</option>
                  <option value="" disabled>──────────</option>
                  <option value="" disabled>Negócios</option>
                  {deals.map(deal => (
                    <option key={deal.id} value={deal.id}>
                      {deal.title} - {deal.company}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="mt-6 flex justify-end gap-4">
              <button
                onClick={() => {
                  setShowNewActivityModal(false);
                  setEditingActivity(null);
                  resetNewActivityForm();
                }}
                className="px-4 py-2 text-gray-400 hover:text-white transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={() => {
                  if (editingActivity) {
                    handleUpdateActivity(editingActivity);
                  } else {
                    handleCreateActivity();
                  }
                }}
                className="bg-[#BFFF04] text-[#1A1A1A] px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-[#BFFF04]/90 transition-colors"
              >
                {editingActivity ? (
                  <>
                    <Check className="h-5 w-5" />
                    Salvar Alterações
                  </>
                ) : (
                  <>
                    <Plus className="h-5 w-5" />
                    Criar Atividade
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}