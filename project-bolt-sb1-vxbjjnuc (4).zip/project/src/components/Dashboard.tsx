import React, { useState } from 'react';
import { BarChart2, Users, CheckCircle, XCircle, Calendar, FileText, TrendingUp } from 'lucide-react';
import { useDeals } from '../hooks/useSupabase';

export function Dashboard() {
  const { deals, calculateMetrics } = useDeals();
  const [dateRange, setDateRange] = useState({
    startDate: '',
    endDate: ''
  });

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const metrics = calculateMetrics(dateRange.startDate, dateRange.endDate);

  const metricsData = [
    {
      title: 'Total em Negociações',
      value: formatCurrency(metrics.totalValue),
      icon: BarChart2,
      color: 'text-blue-500',
      description: 'Valor total de todos os negócios ativos'
    },
    {
      title: 'Negócios Ativos',
      value: metrics.activeDeals,
      icon: Users,
      color: 'text-green-500',
      description: 'Número de negócios em andamento'
    },
    {
      title: 'Negócios Ganhos',
      value: metrics.wonDeals,
      icon: CheckCircle,
      color: 'text-emerald-500',
      description: 'Total de negócios fechados com sucesso'
    },
    {
      title: 'Negócios Perdidos',
      value: metrics.lostDeals,
      icon: XCircle,
      color: 'text-red-500',
      description: 'Total de negócios perdidos ou cancelados'
    },
    {
      title: 'Taxa de Conversão',
      value: `${metrics.conversionRate}%`,
      icon: TrendingUp,
      color: 'text-indigo-500',
      description: 'Percentual de negócios ganhos vs. total'
    }
  ];

  // Calculate stage distribution for the funnel
  const calculateStageDistribution = () => {
    const stages = [
      { id: 'lead', name: 'Leads' },
      { id: 'contact', name: 'Primeiro Contato' },
      { id: 'proposal', name: 'Proposta' },
      { id: 'negotiation', name: 'Negociação' },
      { id: 'closed', name: 'Fechado' }
    ];

    return stages.map(stage => ({
      ...stage,
      count: deals.filter(deal => deal.stage === stage.id).length,
      value: deals
        .filter(deal => deal.stage === stage.id)
        .reduce((sum, deal) => sum + deal.value, 0)
    }));
  };

  const stageDistribution = calculateStageDistribution();

  // Calculate monthly distribution
  const calculateMonthlyDistribution = () => {
    const months = Array.from({ length: 12 }, (_, i) => {
      const date = new Date(2024, i);
      return {
        month: date.toLocaleString('pt-BR', { month: 'short' }),
        value: deals
          .filter(deal => new Date(deal.expectedCloseDate).getMonth() === i)
          .reduce((sum, deal) => sum + deal.value, 0)
      };
    });

    return months;
  };

  const monthlyDistribution = calculateMonthlyDistribution();

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-[#BFFF04]">Dashboard</h1>
        <div className="flex gap-4">
          <input
            type="date"
            className="bg-[#2A2A2A] text-white px-4 py-2 rounded-lg"
            value={dateRange.startDate}
            onChange={(e) => setDateRange(prev => ({...prev, startDate: e.target.value}))}
          />
          <input
            type="date"
            className="bg-[#2A2A2A] text-white px-4 py-2 rounded-lg"
            value={dateRange.endDate}
            onChange={(e) => setDateRange(prev => ({...prev, endDate: e.target.value}))}
          />
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
        {metricsData.map((metric, index) => (
          <div
            key={index}
            className="bg-[#2A2A2A] rounded-lg p-6 shadow-lg hover:shadow-[#BFFF04]/5 transition-all group"
          >
            <div className="flex items-center justify-between mb-4">
              <metric.icon className={`h-8 w-8 ${metric.color} group-hover:scale-110 transition-transform`} />
              <span className="text-2xl font-bold text-white">{metric.value}</span>
            </div>
            <h3 className="text-[#BFFF04] font-medium mb-2">{metric.title}</h3>
            <p className="text-sm text-gray-400">{metric.description}</p>
          </div>
        ))}
      </div>

      <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[#2A2A2A] rounded-lg p-6">
          <h2 className="text-xl font-bold text-[#BFFF04] mb-6">Funil de Vendas</h2>
          <div className="space-y-6">
            {stageDistribution.map((stage, index) => (
              <div key={index} className="relative">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-white capitalize">{stage.name}</span>
                  <div className="text-right">
                    <span className="text-[#BFFF04] block">{stage.count} negócios</span>
                    <span className="text-gray-400 text-sm">
                      {formatCurrency(stage.value)}
                    </span>
                  </div>
                </div>
                <div className="w-full bg-[#1A1A1A] rounded-full h-4 overflow-hidden">
                  <div
                    className="bg-[#BFFF04] h-4 rounded-full transition-all"
                    style={{
                      width: `${(stage.count / Math.max(...stageDistribution.map(s => s.count)) * 100)}%`
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[#2A2A2A] rounded-lg p-6">
          <h2 className="text-xl font-bold text-[#BFFF04] mb-6">Previsão de Fechamento</h2>
          <div className="space-y-4">
            {monthlyDistribution.map((month, index) => (
              <div key={index} className="flex items-center justify-between">
                <span className="text-white capitalize w-20">{month.month}</span>
                <div className="flex-1 mx-4">
                  <div className="w-full bg-[#1A1A1A] rounded-full h-2">
                    <div
                      className="bg-[#BFFF04] h-2 rounded-full transition-all"
                      style={{
                        width: `${(month.value / Math.max(...monthlyDistribution.map(m => m.value)) * 100)}%`
                      }}
                    />
                  </div>
                </div>
                <span className="text-[#BFFF04] text-right w-32">
                  {formatCurrency(month.value)}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}