import React, { useState } from 'react';
import { 
  DollarSign, Plus, Filter, Search, X, Edit2, 
  LayoutGrid, Calendar, List, Building, Phone, Mail, 
  Clock, AlertCircle, Check, Download, ChevronDown, Trash2
} from 'lucide-react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import type { Deal } from '../types';
import toast from 'react-hot-toast';
import { useDeals } from '../hooks/useSupabase';

interface PipelineProps {
  deals: Deal[];
  setDeals: React.Dispatch<React.SetStateAction<Deal[]>>;
}

export function Pipeline({ deals, setDeals }: PipelineProps) {
  const [viewMode, setViewMode] = useState<'kanban' | 'list'>('kanban');
  const [showFilters, setShowFilters] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [selectedStage, setSelectedStage] = useState('');
  const [showNewDealModal, setShowNewDealModal] = useState(false);
  const [editingDeal, setEditingDeal] = useState<Deal | null>(null);
  const [showExportMenu, setShowExportMenu] = useState(false);

  const stages = [
    { id: 'lead', name: 'Leads', color: 'bg-blue-500' },
    { id: 'contact', name: 'Primeiro Contato', color: 'bg-yellow-500' },
    { id: 'proposal', name: 'Proposta', color: 'bg-orange-500' },
    { id: 'negotiation', name: 'Negociação', color: 'bg-purple-500' },
    { id: 'closed', name: 'Fechado', color: 'bg-green-500' },
    { id: 'treasure', name: 'Baú de Leads', color: 'bg-red-500' }
  ];

  const handleDragEnd = (result: any) => {
    const { source, destination, draggableId } = result;

    if (!destination || 
        (source.droppableId === destination.droppableId && 
         source.index === destination.index)) {
      return;
    }

    const draggedDeal = deals.find(deal => deal.id.toString() === draggableId);
    if (!draggedDeal) return;

    const newDeals = Array.from(deals);
    const [removed] = newDeals.splice(
      newDeals.findIndex(deal => deal.id.toString() === draggableId),
      1
    );

    removed.stage = destination.droppableId;

    const insertIndex = newDeals.findIndex(deal => 
      deal.stage === destination.droppableId
    ) + destination.index;

    newDeals.splice(
      insertIndex >= 0 ? insertIndex : newDeals.length,
      0,
      removed
    );

    setDeals(newDeals);
    toast.success(`Negócio movido para ${stages.find(s => s.id === destination.droppableId)?.name}`);
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const filteredDeals = deals.filter(deal => {
    const matchesSearch = deal.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         deal.contact.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStage = selectedStage ? deal.stage === selectedStage : true;
    const dealDate = deal.firstContactDate ? new Date(deal.firstContactDate) : null;
    const start = startDate ? new Date(startDate) : null;
    const end = endDate ? new Date(endDate) : null;
    
    const matchesDateRange = !dealDate || !start || !end || 
      (dealDate >= start && dealDate <= end);
    
    return matchesSearch && matchesStage && matchesDateRange;
  });

  const handleNewDeal = () => {
    const newDealData: Omit<Deal, 'id'> = {
      title: '',
      value: 0,
      stage: 'lead',
      company: '',
      contact: '',
      firstContactDate: new Date().toISOString().split('T')[0],
      probability: 0,
      industry: '',
      email: '',
      phone: '',
      contextInfo: '',
      interactionHistory: '',
      utmCampaign: '',
      utmAdSet: '',
      utmAd: '',
      utmKeyword: ''
    };
    setEditingDeal({ ...newDealData, id: 0 });
    setShowNewDealModal(true);
  };

  const handleSaveDeal = (deal: Deal) => {
    if (!deal.company || !deal.contact) {
      toast.error('Empresa e contato são obrigatórios');
      return;
    }

    if (deal.id === 0) {
      const newDeal = { 
        ...deal, 
        id: deals.length + 1,
        title: `${deal.company} - ${deal.contact}`
      };
      setDeals([...deals, newDeal]);
      toast.success('Novo negócio criado com sucesso!');
    } else {
      setDeals(deals.map(d => d.id === deal.id ? {
        ...deal,
        title: `${deal.company} - ${deal.contact}`
      } : d));
      toast.success('Negócio atualizado com sucesso!');
    }
    setEditingDeal(null);
    setShowNewDealModal(false);
  };

  const handleDeleteDeal = (id: number) => {
    if (confirm('Tem certeza que deseja excluir este negócio?')) {
      setDeals(deals.filter(deal => deal.id !== id));
      toast.success('Negócio excluído com sucesso!');
    }
  };

  const handleExport = (format: 'csv-excel' | 'csv' | 'tsv' | 'pdf' | 'xlsx' | 'xls' | 'google-sheets') => {
    const { exportToCSV, exportToTSV, exportToPDF, exportToExcel, openInGoogleSheets } = useDeals();
    
    const data = deals.map(deal => ({
      'Cliente': deal.contact,
      'Empresa': deal.company,
      'Valor': formatCurrency(deal.value),
      'Estágio': stages.find(s => s.id === deal.stage)?.name,
      'Probabilidade': `${deal.probability}%`,
      'Data de Entrada': new Date(deal.firstContactDate || '').toLocaleDateString('pt-BR'),
      'Campanha': deal.utmCampaign || '-',
      'Conjunto de Anúncios': deal.utmAdSet || '-',
      'Anúncio': deal.utmAd || '-',
      'Palavra-chave': deal.utmKeyword || '-'
    }));

    switch (format) {
      case 'csv-excel':
        exportToCSV(data, 'pipeline-excel.csv', true);
        break;
      case 'csv':
        exportToCSV(data, 'pipeline.csv', false);
        break;
      case 'tsv':
        exportToTSV(data, 'pipeline.tsv');
        break;
      case 'pdf':
        exportToPDF(data, 'pipeline.pdf');
        break;
      case 'xlsx':
      case 'xls':
        exportToExcel(data, `pipeline.${format}`);
        break;
      case 'google-sheets':
        openInGoogleSheets(data);
        break;
    }
    
    setShowExportMenu(false);
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-[#BFFF04]">Pipeline de Vendas</h1>
        <div className="flex flex-wrap items-center gap-4">
          <button
            onClick={() => setViewMode(viewMode === 'kanban' ? 'list' : 'kanban')}
            className="text-[#BFFF04] hover:text-[#BFFF04]/80 transition-colors"
          >
            {viewMode === 'kanban' ? (
              <List className="h-6 w-6" />
            ) : (
              <LayoutGrid className="h-6 w-6" />
            )}
          </button>
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="text-[#BFFF04] hover:text-[#BFFF04]/80 transition-colors"
          >
            <Filter className="h-6 w-6" />
          </button>
          <div className="relative">
            <button
              onClick={() => setShowExportMenu(!showExportMenu)}
              className="text-[#BFFF04] hover:text-[#BFFF04]/80 transition-colors"
            >
              <Download className="h-6 w-6" />
            </button>
            {showExportMenu && (
              <div className="absolute right-0 mt-2 w-48 bg-[#2A2A2A] rounded-lg shadow-lg py-2 z-50">
                <button
                  onClick={() => handleExport('csv-excel')}
                  className="w-full px-4 py-2 text-left text-white hover:bg-[#1A1A1A] transition-colors"
                >
                  CSV (Excel)
                </button>
                <button
                  onClick={() => handleExport('csv')}
                  className="w-full px-4 py-2 text-left text-white hover:bg-[#1A1A1A] transition-colors"
                >
                  CSV
                </button>
                <button
                  onClick={() => handleExport('tsv')}
                  className="w-full px-4 py-2 text-left text-white hover:bg-[#1A1A1A] transition-colors"
                >
                  TSV
                </button>
                <button
                  onClick={() => handleExport('pdf')}
                  className="w-full px-4 py-2 text-left text-white hover:bg-[#1A1A1A] transition-colors"
                >
                  PDF
                </button>
                <button
                  onClick={() => handleExport('xlsx')}
                  className="w-full px-4 py-2 text-left text-white hover:bg-[#1A1A1A] transition-colors"
                >
                  XLSX
                </button>
                <button
                  onClick={() => handleExport('xls')}
                  className="w-full px-4 py-2 text-left text-white hover:bg-[#1A1A1A] transition-colors"
                >
                  XLS
                </button>
                <button
                  onClick={() => handleExport('google-sheets')}
                  className="w-full px-4 py-2 text-left text-white hover:bg-[#1A1A1A] transition-colors"
                >
                  Google Sheets
                </button>
              </div>
            )}
          </div>
          <button
            onClick={handleNewDeal}
            className="bg-[#BFFF04] text-[#1A1A1A] px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-[#BFFF04]/90 transition-colors"
          >
            <Plus className="h-5 w-5" />
            Novo Negócio
          </button>
        </div>
      </div>

      {showFilters && (
        <div className="mb-6 grid grid-cols-1 md:grid-cols-4 gap-4 bg-[#2A2A2A] p-4 rounded-lg">
          <div>
            <label className="block text-sm text-gray-400 mb-1">Buscar</label>
            <input
              type="text"
              placeholder="Buscar negócios..."
              className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#BFFF04]"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1">Data Início</label>
            <input
              type="date"
              className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#BFFF04]"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1">Data Fim</label>
            <input
              type="date"
              className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#BFFF04]"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1">Estágio</label>
            <select
              className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#BFFF04]"
              value={selectedStage}
              onChange={(e) => setSelectedStage(e.target.value)}
            >
              <option value="">Todos</option>
              {stages.map(stage => (
                <option key={stage.id} value={stage.id}>
                  {stage.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      )}

      {viewMode === 'kanban' ? (
        <DragDropContext onDragEnd={handleDragEnd}>
          <div className="flex-1 overflow-x-auto">
            <div className="inline-flex gap-4 min-w-max p-1">
              {stages.map((stage) => (
                <div key={stage.id} className="w-80 flex-shrink-0">
                  <div className="bg-[#2A2A2A] rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-4">
                      <div className={`w-3 h-3 rounded-full ${stage.color}`} />
                      <h2 className="text-lg font-semibold text-[#BFFF04]">{stage.name}</h2>
                    </div>
                    <Droppable droppableId={stage.id}>
                      {(provided) => (
                        <div
                          ref={provided.innerRef}
                          {...provided.droppableProps}
                          className="space-y-4"
                          style={{ minHeight: '200px' }}
                        >
                          {filteredDeals
                            .filter((deal) => deal.stage === stage.id)
                            .map((deal, index) => (
                              <Draggable
                                key={deal.id}
                                draggableId={String(deal.id)}
                                index={index}
                              >
                                {(provided) => (
                                  <div
                                    ref={provided.innerRef}
                                    {...provided.draggableProps}
                                    {...provided.dragHandleProps}
                                    className="bg-[#1A1A1A] rounded-lg p-4 cursor-grab active:cursor-grabbing hover:shadow-lg transition-shadow"
                                  >
                                    <div className="flex justify-between items-start mb-3">
                                      <h3 className="text-white font-medium">{deal.contact}</h3>
                                      <div className="flex gap-2">
                                        <button
                                          onClick={() => setEditingDeal(deal)}
                                          className="text-gray-400 hover:text-[#BFFF04] transition-colors"
                                        >
                                          <Edit2 className="h-5 w-5" />
                                        </button>
                                        <button
                                          onClick={() => handleDeleteDeal(deal.id)}
                                          className="text-gray-400 hover:text-red-500 transition-colors"
                                        >
                                          <Trash2 className="h-5 w-5" />
                                        </button>
                                      </div>
                                    </div>
                                    <div className="space-y-2">
                                      <div className="flex items-center gap-2 text-gray-400">
                                        <Building className="h-4 w-4" />
                                        <span className="text-sm">{deal.company}</span>
                                      </div>
                                      <div className="flex items-center gap-2 text-[#BFFF04]">
                                        <DollarSign className="h-4 w-4" />
                                        <span className="text-sm">{formatCurrency(deal.value)}</span>
                                      </div>
                                      <div className="flex items-center gap-2 text-gray-400">
                                        <Calendar className="h-4 w-4" />
                                        <span className="text-sm">
                                          {new Date(deal.firstContactDate || '').toLocaleDateString('pt-BR')}
                                        </span>
                                      </div>
                                    </div>
                                  </div>
                                )}
                              </Draggable>
                            ))}
                          {provided.placeholder}
                        </div>
                      )}
                    </Droppable>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </DragDropContext>
      ) : (
        <div className="bg-[#2A2A2A] rounded-lg overflow-x-auto">
          <table className="w-full min-w-[800px]">
            <thead>
              <tr className="bg-[#1A1A1A]">
                <th className="px-4 py-3 text-left text-[#BFFF04] font-medium">Cliente</th>
                <th className="px-4 py-3 text-left text-[#BFFF04] font-medium">Empresa</th>
                <th className="px-4 py-3 text-left text-[#BFFF04] font-medium">Valor</th>
                <th className="px-4 py-3 text-left text-[#BFFF04] font-medium">Estágio</th>
                <th className="px-4 py-3 text-left text-[#BFFF04] font-medium">Data de Entrada</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {filteredDeals.map((deal) => (
                <tr key={deal.id} className="border-t border-[#1A1A1A] hover:bg-[#1A1A1A]/50">
                  <td className="px-4 py-3 text-white">{deal.contact}</td>
                  <td className="px-4 py-3 text-gray-400">{deal.company}</td>
                  <td className="px-4 py-3 text-[#BFFF04]">{formatCurrency(deal.value)}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full ${stages.find(s => s.id === deal.stage)?.color}`} />
                      <span className="text-white">
                        {stages.find(s => s.id === deal.stage)?.name}
                      </span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-gray-400">
                    {new Date(deal.firstContactDate || '').toLocaleDateString('pt-BR')}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex gap-2">
                      <button
                        onClick={() => setEditingDeal(deal)}
                        className="text-gray-400 hover:text-[#BFFF04] transition-colors"
                      >
                        <Edit2 className="h-5 w-5" />
                      </button>
                      <button
                        onClick={() => handleDeleteDeal(deal.id)}
                        className="text-gray-400 hover:text-red-500 transition-colors"
                      >
                        <Trash2 className="h-5 w-5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {(showNewDealModal || editingDeal) && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-[#2A2A2A] rounded-lg p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-[#BFFF04]">
                {editingDeal?.id === 0 ? 'Novo Negócio' : 'Editar Negócio'}
              </h2>
              <button
                onClick={() => {
                  setEditingDeal(null);
                  setShowNewDealModal(false);
                }}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Empresa *</label>
                  <input
                    type="text"
                    className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                    value={editingDeal?.company}
                    onChange={(e) => setEditingDeal(prev => prev ? {...prev, company: e.target.value} : null)}
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Cliente *</label>
                  <input
                    type="text"
                    className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                    value={editingDeal?.contact}
                    onChange={(e) => setEditingDeal(prev => prev ? {...prev, contact: e.target.value} : null)}
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Valor</label>
                  <input
                    type="number"
                    className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                    value={editingDeal?.value}
                    onChange={(e) => setEditingDeal(prev => prev ? {...prev, value: Number(e.target.value)} : null)}
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Nicho</label>
                  <input
                    type="text"
                    className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                    value={editingDeal?.industry}
                    onChange={(e) => setEditingDeal(prev => prev ? {...prev, industry: e.target.value} : null)}
                  />
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Data de Entrada</label>
                  <input
                    type="date"
                    className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                    value={editingDeal?.firstContactDate}
                    onChange={(e) => setEditingDeal(prev => prev ? {...prev, firstContactDate: e.target.value} : null)}
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Probabilidade (%)</label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                    value={editingDeal?.probability}
                    onChange={(e) => setEditingDeal(prev => prev ? {...prev, probability: Number(e.target.value)} : null)}
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Estágio</label>
                  <select
                    className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                    value={editingDeal?.stage}
                    onChange={(e) => setEditingDeal(prev => prev ? {...prev, stage: e.target.value} : null)}
                  >
                    {stages.map(stage => (
                      <option key={stage.id} value={stage.id}>{stage.name}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            <div className="mt-6">
              <h3 className="text-white font-medium mb-4">Informações de Contato</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-1">E-mail</label>
                  <input
                    type="email"
                    className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                    value={editingDeal?.email}
                    onChange={(e) => setEditingDeal(prev => prev ? {...prev, email: e.target.value} : null)}
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Telefone</label>
                  <input
                    type="tel"
                    className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                    value={editingDeal?.phone}
                    onChange={(e) => setEditingDeal(prev => prev ? {...prev, phone: e.target.value} : null)}
                  />
                </div>
              </div>
            </div>

            <div className="mt-6">
              <h3 className="text-white font-medium mb-4">Informações Adicionais</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Informações Contextuais</label>
                  <textarea
                    className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white h-24"
                    value={editingDeal?.contextInfo}
                    onChange={(e) => setEditingDeal(prev => prev ? {...prev, contextInfo: e.target.value} : null)}
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Histórico de Interações</label>
                  <textarea
                    className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white h-24"
                    value={editingDeal?.interactionHistory}
                    onChange={(e) => setEditingDeal(prev => prev ? {...prev, interactionHistory: e.target.value} : null)}
                  />
                </div>
              </div>
            </div>

            <div className="mt-6">
              <h3 className="text-white font-medium mb-4">Informações de Campanha</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Campanha</label>
                  <input
                    type="text"
                    className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                    value={editingDeal?.utmCampaign}
                    onChange={(e) => setEditingDeal(prev => prev ? {...prev, utmCampaign: e.target.value} : null)}
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Conjunto de Anúncios</label>
                  <input
                    type="text"
                    className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                    value={editingDeal?.utmAdSet}
                    onChange={(e) => setEditingDeal(prev => prev ? {...prev, utmAdSet: e.target.value} : null)}
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Anúncio</label>
                  <input
                    type="text"
                    className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                    value={editingDeal?.utmAd}
                    onChange={(e) => setEditingDeal(prev => prev ? {...prev, utmAd: e.target.value} : null)}
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb- 1">Palavra-chave</label>
                  <input
                    type="text"
                    className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                    value={editingDeal?.utmKeyword}
                    onChange={(e) => setEditingDeal(prev => prev ? {...prev, utmKeyword: e.target.value} : null)}
                  />
                </div>
              </div>
            </div>

            <div className="mt-6 flex justify-end gap-4">
              <button
                onClick={() => {
                  setEditingDeal(null);
                  setShowNewDealModal(false);
                }}
                className="px-4 py-2 text-gray-400 hover:text-white transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={() => editingDeal && handleSaveDeal(editingDeal)}
                className="bg-[#BFFF04] text-[#1A1A1A] px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-[#BFFF04]/90 transition-colors"
              >
                <Check className="h-5 w-5" />
                {editingDeal?.id === 0 ? 'Criar Negócio' : 'Salvar Alterações'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}