import React, { useState, useEffect } from 'react';
import { Search, Plus, Mail, Phone, Building, Calendar, Edit2, X, Check } from 'lucide-react';
import { mockContacts } from '../data/mockData';
import type { Contact } from '../types';
import { useDeals } from '../hooks/useSupabase';
import toast from 'react-hot-toast';

export function Contacts() {
  const [searchTerm, setSearchTerm] = useState('');
  const [contacts, setContacts] = useState<Contact[]>(mockContacts);
  const [editingContact, setEditingContact] = useState<Contact | null>(null);
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');
  const [showNewContactModal, setShowNewContactModal] = useState(false);
  const [newContact, setNewContact] = useState<Partial<Contact>>({
    name: '',
    email: '',
    phone: '',
    company: '',
    position: '',
    lastContact: new Date().toISOString().split('T')[0],
    status: 'active'
  });
  const { deals } = useDeals();

  const formatDateToLocal = (date: string) => {
    if (!date) return '';
    const [year, month, day] = date.split('-');
    return `${day}/${month}/${year}`;
  };

  const parseLocalDate = (dateString: string) => {
    if (!dateString) return '';
    const [day, month, year] = dateString.split('/');
    return `${year}-${month}-${day}`;
  };

  const getTodayDate = () => {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  useEffect(() => {
    const pipelineContacts = deals.map(deal => ({
      id: deal.id,
      name: deal.contact,
      email: deal.email || '',
      phone: deal.phone || '',
      company: deal.company,
      position: '',
      lastContact: deal.firstContactDate || new Date().toISOString().split('T')[0],
      status: 'active' as const
    }));

    const mergedContacts = [...contacts];
    pipelineContacts.forEach(pipelineContact => {
      if (!contacts.some(contact => contact.id === pipelineContact.id)) {
        mergedContacts.push(pipelineContact);
      }
    });

    setContacts(mergedContacts.sort((a, b) => a.name.localeCompare(b.name)));
  }, [deals]);

  const filteredContacts = contacts.filter(contact =>
    (contact.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
     contact.company.toLowerCase().includes(searchTerm.toLowerCase())) &&
    (statusFilter === 'all' || contact.status === statusFilter)
  );

  const handleEdit = (contact: Contact) => {
    setEditingContact(contact);
  };

  const handleSave = (contact: Contact) => {
    setContacts(contacts.map(c => c.id === contact.id ? contact : c));
    setEditingContact(null);
    toast.success('Contato atualizado com sucesso');
  };

  const handleCancel = () => {
    setEditingContact(null);
  };

  const handleCreateContact = () => {
    if (!newContact.name || !newContact.company) {
      toast.error('Nome e empresa são obrigatórios');
      return;
    }

    const contact: Contact = {
      id: contacts.length + 1,
      name: newContact.name,
      email: newContact.email || '',
      phone: newContact.phone || '',
      company: newContact.company,
      position: newContact.position || '',
      lastContact: newContact.lastContact || new Date().toISOString().split('T')[0],
      status: newContact.status as 'active' | 'inactive'
    };

    setContacts([...contacts, contact]);
    toast.success('Contato criado com sucesso!');
    setShowNewContactModal(false);
    resetNewContactForm();
  };

  const resetNewContactForm = () => {
    setNewContact({
      name: '',
      email: '',
      phone: '',
      company: '',
      position: '',
      lastContact: new Date().toISOString().split('T')[0],
      status: 'active'
    });
  };

  const getStatusColor = (status: string) => {
    return status === 'active' 
      ? 'bg-green-500/20 text-green-500'
      : 'bg-gray-500/20 text-gray-500';
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-[#BFFF04]">Contatos</h1>
        <button 
          onClick={() => setShowNewContactModal(true)}
          className="bg-[#BFFF04] text-[#1A1A1A] px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-[#BFFF04]/90 transition-colors"
        >
          <Plus className="h-5 w-5" />
          Novo Contato
        </button>
      </div>

      <div className="mb-6 flex gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Buscar contatos..."
              className="w-full pl-10 pr-4 py-2 bg-[#2A2A2A] rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#BFFF04]"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <select
          className="bg-[#2A2A2A] text-white px-4 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#BFFF04]"
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value as 'all' | 'active' | 'inactive')}
        >
          <option value="all">Todos os status</option>
          <option value="active">Ativos</option>
          <option value="inactive">Inativos</option>
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredContacts.map((contact) => (
          <div
            key={contact.id}
            className="bg-[#2A2A2A] rounded-lg p-6 hover:shadow-lg transition-all"
          >
            {editingContact?.id === contact.id ? (
              <>
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <input
                      className="w-full bg-[#1A1A1A] text-white px-3 py-2 rounded mb-2"
                      value={editingContact.name}
                      onChange={(e) => setEditingContact({...editingContact, name: e.target.value})}
                    />
                    <input
                      className="w-full bg-[#1A1A1A] text-[#BFFF04] px-3 py-2 rounded"
                      value={editingContact.position}
                      onChange={(e) => setEditingContact({...editingContact, position: e.target.value})}
                    />
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleSave(editingContact)}
                      className="text-green-500 hover:text-green-400 transition-colors"
                    >
                      <Check className="h-5 w-5" />
                    </button>
                    <button
                      onClick={handleCancel}
                      className="text-red-500 hover:text-red-400 transition-colors"
                    >
                      <X className="h-5 w-5" />
                    </button>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Mail className="h-4 w-4 text-gray-400" />
                    <input
                      className="flex-1 bg-[#1A1A1A] text-white px-3 py-1 rounded"
                      value={editingContact.email}
                      onChange={(e) => setEditingContact({...editingContact, email: e.target.value})}
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-gray-400" />
                    <input
                      className="flex-1 bg-[#1A1A1A] text-white px-3 py-1 rounded"
                      value={editingContact.phone}
                      onChange={(e) => setEditingContact({...editingContact, phone: e.target.value})}
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <Building className="h-4 w-4 text-gray-400" />
                    <input
                      className="flex-1 bg-[#1A1A1A] text-white px-3 py-1 rounded"
                      value={editingContact.company}
                      onChange={(e) => setEditingContact({...editingContact, company: e.target.value})}
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-gray-400" />
                    <input
                      type="date"
                      className="flex-1 bg-[#1A1A1A] text-white px-3 py-1 rounded"
                      value={editingContact.lastContact.split('T')[0]}
                      onChange={(e) => setEditingContact({...editingContact, lastContact: e.target.value})}
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <select
                      className="flex-1 bg-[#1A1A1A] text-white px-3 py-1 rounded"
                      value={editingContact.status}
                      onChange={(e) => setEditingContact({
                        ...editingContact,
                        status: e.target.value as 'active' | 'inactive'
                      })}
                    >
                      <option value="active">Ativo</option>
                      <option value="inactive">Inativo</option>
                    </select>
                  </div>
                </div>
              </>
            ) : (
              <>
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-white">{contact.name}</h3>
                    <p className="text-[#BFFF04]">{contact.position}</p>
                  </div>
                  <div className="flex gap-2 items-center">
                    <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(contact.status)}`}>
                      {contact.status === 'active' ? 'Ativo' : 'Inativo'}
                    </span>
                    <button
                      onClick={() => handleEdit(contact)}
                      className="text-gray-400 hover:text-[#BFFF04] transition-colors"
                    >
                      <Edit2 className="h-5 w-5" />
                    </button>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-gray-300">
                    <Mail className="h-4 w-4" />
                    <span>{contact.email}</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-300">
                    <Phone className="h-4 w-4" />
                    <span>{contact.phone}</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-300">
                    <Building className="h-4 w-4" />
                    <span>{contact.company}</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-300">
                    <Calendar className="h-4 w-4" />
                    <span>Último contato: {formatDateToLocal(contact.lastContact)}</span>
                  </div>
                </div>
              </>
            )}
          </div>
        ))}
      </div>

      {showNewContactModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-[#2A2A2A] rounded-lg p-6 max-w-2xl w-full">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-[#BFFF04]">Novo Contato</h2>
              <button
                onClick={() => {
                  setShowNewContactModal(false);
                  resetNewContactForm();
                }}
                className="text-gray-400 hover:text-white"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm text-gray-400 mb-1">Nome *</label>
                <input
                  type="text"
                  className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                  value={newContact.name}
                  onChange={(e) => setNewContact({...newContact, name: e.target.value})}
                />
              </div>

              <div>
                <label className="block text-sm text-gray-400 mb-1">E-mail</label>
                <input
                  type="email"
                  className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                  value={newContact.email}
                  onChange={(e) => setNewContact({...newContact, email: e.target.value})}
                />
              </div>

              <div>
                <label className="block text-sm text-gray-400 mb-1">Telefone</label>
                <input
                  type="tel"
                  className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                  value={newContact.phone}
                  onChange={(e) => setNewContact({...newContact, phone: e.target.value})}
                />
              </div>

              <div>
                <label className="block text-sm text-gray-400 mb-1">Empresa *</label>
                <input
                  type="text"
                  className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                  value={newContact.company}
                  onChange={(e) => setNewContact({...newContact, company: e.target.value})}
                />
              </div>

              <div>
                <label className="block text-sm text-gray-400 mb-1">Cargo</label>
                <input
                  type="text"
                  className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                  value={newContact.position}
                  onChange={(e) => setNewContact({...newContact, position: e.target.value})}
                />
              </div>

              <div>
                <label className="block text-sm text-gray-400 mb-1">Último Contato</label>
                <input
                  type="date"
                  className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                  value={newContact.lastContact?.split('T')[0]}
                  onChange={(e) => setNewContact({...newContact, lastContact: e.target.value})}
                />
              </div>

              <div>
                <label className="block text-sm text-gray-400 mb-1">Status</label>
                <select
                  className="w-full px-4 py-2 bg-[#1A1A1A] rounded-lg text-white"
                  value={newContact.status}
                  onChange={(e) => setNewContact({...newContact, status: e.target.value as 'active' | 'inactive'})}
                >
                  <option value="active">Ativo</option>
                  <option value="inactive">Inativo</option>
                </select>
              </div>
            </div>

            <div className="mt-6 flex justify-end gap-4">
              <button
                onClick={() => {
                  setShowNewContactModal(false);
                  resetNewContactForm();
                }}
                className="px-4 py-2 text-gray-400 hover:text-white transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={handleCreateContact}
                className="bg-[#BFFF04] text-[#1A1A1A] px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-[#BFFF04]/90 transition-colors"
              >
                <Plus className="h-5 w-5" />
                Criar Contato
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}