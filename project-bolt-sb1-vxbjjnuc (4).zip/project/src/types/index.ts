export interface Deal {
  id: number;
  title: string;
  value: number;
  stage: string;
  company: string;
  contact: string;
  firstContactDate: string;
  probability: number;
  lastActivity?: string;
  responsibleName?: string;
  phone?: string;
  email?: string;
  industry?: string;
  contactResponsible?: string;
  companyResponsible?: string;
  contextInfo?: string;
  interactionHistory?: string;
  utmCampaign?: string;
  utmAdSet?: string;
  utmAd?: string;
  utmKeyword?: string;
}

export interface Contact {
  id: number;
  name: string;
  email: string;
  phone: string;
  company: string;
  position: string;
  lastContact: string;
  status: 'active' | 'inactive';
}

export interface Activity {
  id: number;
  type: 'call' | 'meeting' | 'email' | 'task';
  title: string;
  description: string;
  date: string;
  status: 'pending' | 'completed';
  relatedTo: {
    type: 'deal' | 'contact' | 'personal';
    id: number;
    name: string;
  };
}

export interface Proposal {
  id: number;
  title: string;
  dealId: number;
  dealTitle: string;
  company: string;
  value: number;
  status: 'a_enviar' | 'enviado' | 'aguardando_aprovacao' | 'aprovado' | 'recusado';
  createdAt: string;
  validUntil: string;
  driveLink?: string;
  documents: Array<{
    id: number;
    name: string;
    url: string;
  }>;
}

export interface ExportOptions {
  format: 'csv-excel' | 'csv' | 'tsv' | 'pdf' | 'xlsx' | 'xls' | 'google-sheets';
  filename: string;
  data: Record<string, any>[];
}