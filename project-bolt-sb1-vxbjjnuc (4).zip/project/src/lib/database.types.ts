export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      activities: {
        Row: {
          id: string
          type: string
          title: string
          description: string | null
          date: string
          status: string
          deal_id: string | null
          contact_id: string | null
          created_at: string | null
          updated_at: string | null
        }
        Insert: {
          id?: string
          type: string
          title: string
          description?: string | null
          date: string
          status?: string
          deal_id?: string | null
          contact_id?: string | null
          created_at?: string | null
          updated_at?: string | null
        }
        Update: {
          id?: string
          type?: string
          title?: string
          description?: string | null
          date?: string
          status?: string
          deal_id?: string | null
          contact_id?: string | null
          created_at?: string | null
          updated_at?: string | null
        }
      }
      companies: {
        Row: {
          id: string
          name: string
          industry: string | null
          website: string | null
          phone: string | null
          address: string | null
          created_at: string | null
          updated_at: string | null
        }
        Insert: {
          id?: string
          name: string
          industry?: string | null
          website?: string | null
          phone?: string | null
          address?: string | null
          created_at?: string | null
          updated_at?: string | null
        }
        Update: {
          id?: string
          name?: string
          industry?: string | null
          website?: string | null
          phone?: string | null
          address?: string | null
          created_at?: string | null
          updated_at?: string | null
        }
      }
      contacts: {
        Row: {
          id: string
          name: string
          email: string | null
          phone: string | null
          position: string | null
          company_id: string | null
          status: string | null
          last_contact: string | null
          created_at: string | null
          updated_at: string | null
        }
        Insert: {
          id?: string
          name: string
          email?: string | null
          phone?: string | null
          position?: string | null
          company_id?: string | null
          status?: string | null
          last_contact?: string | null
          created_at?: string | null
          updated_at?: string | null
        }
        Update: {
          id?: string
          name?: string
          email?: string | null
          phone?: string | null
          position?: string | null
          company_id?: string | null
          status?: string | null
          last_contact?: string | null
          created_at?: string | null
          updated_at?: string | null
        }
      }
      deals: {
        Row: {
          id: string
          title: string
          value: number
          stage: string
          company_id: string | null
          contact_id: string | null
          expected_close_date: string | null
          probability: number | null
          last_activity: string | null
          created_at: string | null
          updated_at: string | null
        }
        Insert: {
          id?: string
          title: string
          value: number
          stage: string
          company_id?: string | null
          contact_id?: string | null
          expected_close_date?: string | null
          probability?: number | null
          last_activity?: string | null
          created_at?: string | null
          updated_at?: string | null
        }
        Update: {
          id?: string
          title?: string
          value?: number
          stage?: string
          company_id?: string | null
          contact_id?: string | null
          expected_close_date?: string | null
          probability?: number | null
          last_activity?: string | null
          created_at?: string | null
          updated_at?: string | null
        }
      }
      proposals: {
        Row: {
          id: string
          title: string
          deal_id: string | null
          value: number
          status: string | null
          valid_until: string | null
          created_at: string | null
          updated_at: string | null
        }
        Insert: {
          id?: string
          title: string
          deal_id?: string | null
          value: number
          status?: string | null
          valid_until?: string | null
          created_at?: string | null
          updated_at?: string | null
        }
        Update: {
          id?: string
          title?: string
          deal_id?: string | null
          value?: number
          status?: string | null
          valid_until?: string | null
          created_at?: string | null
          updated_at?: string | null
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      get_dashboard_metrics: {
        Args: Record<PropertyKey, never>
        Returns: Json
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}