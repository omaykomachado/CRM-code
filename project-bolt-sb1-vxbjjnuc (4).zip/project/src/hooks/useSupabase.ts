import { useState } from 'react';
import { mockDeals, mockContacts, mockActivities, mockProposals } from '../data/mockData';
import type { Deal, Contact, Activity, Proposal, ExportOptions } from '../types';
import toast from 'react-hot-toast';
import Papa from 'papaparse';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import * as XLSX from 'xlsx';

// Export functions
export const exportToCSV = (data: Record<string, any>[], filename: string, forExcel: boolean = false) => {
  const csv = Papa.unparse(data, {
    delimiter: forExcel ? ';' : ',',
    encoding: forExcel ? 'UTF-8' : 'UTF-8'
  });
  const blob = new Blob([forExcel ? '\uFEFF' + csv : csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

export const exportToTSV = (data: Record<string, any>[], filename: string) => {
  const tsv = Papa.unparse(data, {
    delimiter: '\t'
  });
  const blob = new Blob([tsv], { type: 'text/tab-separated-values;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

export const exportToPDF = (data: Record<string, any>[], filename: string) => {
  const doc = new jsPDF();
  const headers = Object.keys(data[0]);
  const rows = data.map(obj => Object.values(obj));
  
  (doc as any).autoTable({
    head: [headers],
    body: rows,
    theme: 'grid',
    styles: { fontSize: 8 },
    headStyles: { fillColor: [191, 255, 4] }
  });
  
  doc.save(filename);
};

export const exportToExcel = (data: Record<string, any>[], filename: string) => {
  const ws = XLSX.utils.json_to_sheet(data);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
  XLSX.writeFile(wb, filename);
};

export const openInGoogleSheets = (data: Record<string, any>[]) => {
  const csv = Papa.unparse(data);
  const encodedData = encodeURIComponent(csv);
  const url = `https://docs.google.com/spreadsheets/d/create?usp=sheets_api&data=${encodedData}`;
  window.open(url, '_blank');
};

// Hooks
export const useDeals = () => {
  const [deals, setDeals] = useState<Deal[]>(mockDeals);
  const [loading, setLoading] = useState(false);

  const updateDeal = async (id: number, updates: Partial<Deal>) => {
    try {
      setLoading(true);
      const updatedDeals = deals.map(deal => 
        deal.id === id ? { ...deal, ...updates } : deal
      );
      setDeals(updatedDeals);
      toast.success('Negócio atualizado com sucesso');
    } catch (error) {
      toast.error('Erro ao atualizar negócio');
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const createDeal = async (deal: Omit<Deal, 'id'>) => {
    try {
      setLoading(true);
      const newDeal = {
        ...deal,
        id: deals.length + 1
      };
      setDeals([...deals, newDeal]);
      toast.success('Negócio criado com sucesso');
    } catch (error) {
      toast.error('Erro ao criar negócio');
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateMetrics = (startDate?: string, endDate?: string) => {
    const filteredDeals = deals.filter(deal => {
      if (!startDate && !endDate) return true;
      const dealDate = new Date(deal.firstContactDate);
      const start = startDate ? new Date(startDate) : null;
      const end = endDate ? new Date(endDate) : null;
      return (!start || dealDate >= start) && (!end || dealDate <= end);
    });

    const totalValue = filteredDeals.reduce((sum, deal) => sum + deal.value, 0);
    const wonDeals = filteredDeals.filter(deal => deal.stage === 'closed').length;
    const lostDeals = filteredDeals.filter(deal => deal.stage === 'treasure').length;
    const activeDeals = filteredDeals.filter(deal => 
      deal.stage !== 'closed' && deal.stage !== 'treasure'
    ).length;
    const conversionRate = filteredDeals.length > 0 
      ? ((wonDeals / filteredDeals.length) * 100).toFixed(1)
      : '0';

    return {
      totalValue,
      wonDeals,
      lostDeals,
      activeDeals,
      conversionRate
    };
  };

  return { 
    deals, 
    setDeals, 
    loading, 
    updateDeal, 
    createDeal,
    calculateMetrics,
    exportToCSV,
    exportToTSV,
    exportToPDF,
    exportToExcel,
    openInGoogleSheets
  };
};