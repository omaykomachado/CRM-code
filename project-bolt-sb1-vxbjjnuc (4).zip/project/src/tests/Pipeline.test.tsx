import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import { Pipeline } from '../components/Pipeline';
import type { Deal } from '../types';

// Mock deals para teste
const mockDeals: Deal[] = [
  {
    id: 1,
    title: 'Projeto A',
    value: 50000,
    stage: 'lead',
    company: 'Tech Corp',
    contact: 'João Silva',
    expectedCloseDate: '2024-05-15',
    probability: 60,
    firstContactDate: '2024-02-01',
    industry: 'Tecnologia',
    email: 'joao@techcorp.com',
    phone: '(11) 99999-9999',
    contextInfo: '',
    interactionHistory: ''
  },
  {
    id: 2,
    title: 'Consultoria B',
    value: 75000,
    stage: 'contact',
    company: 'Inovação Ltd',
    contact: 'Maria Santos',
    expectedCloseDate: '2024-04-20',
    probability: 40,
    firstContactDate: '2024-02-15',
    industry: 'Consultoria',
    email: 'maria@inovacao.com',
    phone: '(11) 88888-8888',
    contextInfo: '',
    interactionHistory: ''
  },
];

// Mock do react-hot-toast
vi.mock('react-hot-toast', () => ({
  default: {
    success: vi.fn(),
    error: vi.fn(),
  },
}));

// Mock do @hello-pangea/dnd
vi.mock('@hello-pangea/dnd', () => ({
  DragDropContext: ({ children }: { children: React.ReactNode }) => children,
  Droppable: ({ children }: { children: Function }) => children({
    draggableProps: {},
    innerRef: null,
    placeholder: null,
  }, {}),
  Draggable: ({ children }: { children: Function }) => children({
    draggableProps: {},
    dragHandleProps: {},
    innerRef: null,
  }, {}),
}));

describe('Pipeline Component', () => {
  const setDeals = vi.fn();

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('renders all pipeline stages', () => {
    render(<Pipeline deals={mockDeals} setDeals={setDeals} />);
    
    const stages = [
      'Leads',
      'Primeiro Contato',
      'Proposta',
      'Negociação',
      'Fechado',
      'Baú de Leads'
    ];
    
    stages.forEach(stage => {
      expect(screen.getByText(stage)).toBeInTheDocument();
    });
  });

  it('displays deals in correct stages', () => {
    render(<Pipeline deals={mockDeals} setDeals={setDeals} />);
    
    expect(screen.getByText('Projeto A')).toBeInTheDocument();
    expect(screen.getByText('Consultoria B')).toBeInTheDocument();
    expect(screen.getByText('Tech Corp')).toBeInTheDocument();
    expect(screen.getByText('Inovação Ltd')).toBeInTheDocument();
  });

  it('formats currency values correctly', () => {
    render(<Pipeline deals={mockDeals} setDeals={setDeals} />);
    
    const formattedValues = mockDeals.map(deal => 
      new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' })
        .format(deal.value)
    );
    
    formattedValues.forEach(value => {
      expect(screen.getByText(value)).toBeInTheDocument();
    });
  });

  it('opens new deal modal when clicking new deal button', () => {
    render(<Pipeline deals={mockDeals} setDeals={setDeals} />);
    
    const newDealButton = screen.getByText('Novo Negócio');
    fireEvent.click(newDealButton);
    
    expect(screen.getByText('Novo Negócio')).toBeInTheDocument();
    expect(screen.getByText('Salvar')).toBeInTheDocument();
  });

  it('filters deals based on search term', () => {
    render(<Pipeline deals={mockDeals} setDeals={setDeals} />);
    
    // Abrir filtros
    const filterButton = screen.getByRole('button', { name: /filter/i });
    fireEvent.click(filterButton);
    
    // Buscar por "Tech"
    const searchInput = screen.getByPlaceholderText('Buscar negócios...');
    fireEvent.change(searchInput, { target: { value: 'Tech' } });
    
    expect(screen.getByText('Projeto A')).toBeInTheDocument();
    expect(screen.queryByText('Consultoria B')).not.toBeInTheDocument();
  });

  it('toggles between kanban and list views', () => {
    render(<Pipeline deals={mockDeals} setDeals={setDeals} />);
    
    // Inicialmente em modo kanban
    expect(screen.queryByRole('table')).not.toBeInTheDocument();
    
    // Mudar para visualização em lista
    const viewToggleButton = screen.getByRole('button', { name: /list/i });
    fireEvent.click(viewToggleButton);
    
    // Agora deve mostrar uma tabela
    expect(screen.getByRole('table')).toBeInTheDocument();
  });
});